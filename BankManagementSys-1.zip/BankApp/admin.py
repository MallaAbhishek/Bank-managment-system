from django.contrib import admin
from .models import UserDetails,Transactions
# Register your models here.
admin.site.register(UserDetails)
admin.site.register(Transactions)