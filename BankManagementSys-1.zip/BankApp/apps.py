from django.apps import AppConfig


class BankappConfig(AppConfig):
    name = 'BankApp'
